--== DO NOT DISTRIBUTE ==--

This is a set of compiled classes from Sun's KVM and MIDP stacks.
It contains the entire MIDP 2.0 stack compiled from the midp2.0fcs
reference implementation. The multimedia stuff was stripped, and
class com.sun.midp.lcdui.DefaultEventHandler is in the patched
version for the SONiVOX implementation.

It is solely meant to help for developing with IDE's so that you
can add it as external class library instead of a J2SE classes.zip.

It is not needed to build the MIDP emulator phone from scratch:
for that, this library is created during compilation from the
sources in the MIDP and KVM source repositories.
