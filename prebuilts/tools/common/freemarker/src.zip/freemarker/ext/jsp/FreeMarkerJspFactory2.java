package freemarker.ext.jsp;


/**
 * @author Attila Szegedi
 * @version $Id: $
 */
class FreeMarkerJspFactory2 extends FreeMarkerJspFactory
{
    protected String getSpecificationVersion() {
        return "2.0";
    }
}